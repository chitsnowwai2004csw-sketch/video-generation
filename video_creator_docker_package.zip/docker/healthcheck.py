import json
import os
import urllib.request
from pathlib import Path

key = Path(os.environ["VIDEO_API_KEY_FILE"]).read_text().strip()
request = urllib.request.Request("http://127.0.0.1:8001/health", headers={
    "Authorization": "Bearer " + key, "X-OpenWebUI-User-ID": "healthcheck"
})
with urllib.request.urlopen(request, timeout=5) as response:
    if json.load(response).get("ready") is not True:
        raise SystemExit(1)
