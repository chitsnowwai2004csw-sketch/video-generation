"""Host-side integration check for the isolated Docker Compose stack.

Run after `docker compose up -d`. Creates local test accounts, configures the
Pipe through the included installer, and renders with both real Linux adapters.
"""
import io
import json
import os
import re
import secrets
import subprocess
import time
from pathlib import Path

import httpx
from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parents[1]
STATE = ROOT / ".docker-test"
STATE.mkdir(exist_ok=True)
BASE = os.getenv("DOCKER_TEST_URL", "http://127.0.0.1:3000")
credentials_path = STATE / "credentials.json"
if credentials_path.is_file():
    credentials = json.loads(credentials_path.read_text())
else:
    credentials = {"email": "docker-video-admin@example.com", "password": secrets.token_urlsafe(30)}
    credentials_path.write_text(json.dumps(credentials))
client = httpx.Client(base_url=BASE, timeout=180, trust_env=False)
report = {"checks": [], "base_url": BASE}


def check(name, condition):
    if not condition:
        raise AssertionError(name)
    report["checks"].append(name)
    print("PASS " + name, flush=True)


def api(method, path, token=None, **kwargs):
    response = client.request(method, path, headers={"Authorization": "Bearer " + token} if token else {}, **kwargs)
    if response.status_code >= 400:
        raise RuntimeError(f"{method} {path}: HTTP {response.status_code}: {response.text[:300]}")
    return response.json()


def completion(user, text, files=None):
    body = {"model": "video_creator", "messages": [{"role": "user", "content": text}], "stream": False}
    if files:
        body["files"] = files
    return api("POST", "/api/chat/completions", user["token"], json=body)["choices"][0]["message"]["content"]


def docker(*arguments, input=None):
    result = subprocess.run(["docker", "compose", *arguments], cwd=ROOT, input=input,
                            text=True, encoding="utf-8", errors="replace", capture_output=True, timeout=300)
    if result.returncode:
        raise RuntimeError("Docker command failed: " + (result.stderr + result.stdout)[-2000:])
    return result.stdout


print("Waiting for the Docker gateway...", flush=True)
for _ in range(180):
    try:
        if client.get("/health", timeout=2).status_code == 200:
            break
    except httpx.HTTPError:
        pass
    time.sleep(2)
else:
    raise RuntimeError("Docker stack did not become ready")
response = client.post("/api/v1/auths/signin", json=credentials)
if response.status_code == 200:
    admin = response.json()
else:
    admin = api("POST", "/api/v1/auths/signup", json={**credentials, "name": "Docker Video Test Admin"})
check("Administrator account in containerized Open WebUI", admin["role"] == "admin")
configured = docker("--profile", "tools", "run", "--rm", "-T", "configure", "--credentials-stdin", input=json.dumps(credentials))
check("Automatic Pipe installation, sharing, and key configuration", "shared tools are ready" in configured)
check("All shared tools ready through the gateway", "**ready**" in completion(admin, "/health"))

users = []
for number in (1, 2):
    email = f"docker-video-user-{number}@example.com"
    response = client.post("/api/v1/auths/signin", json={"email": email, "password": credentials["password"]})
    if response.status_code != 200:
        api("POST", "/api/v1/auths/add", admin["token"], json={"name": f"Docker Video User {number}", "email": email, "password": credentials["password"], "role": "user"})
        response = client.post("/api/v1/auths/signin", json={"email": email, "password": credentials["password"]})
    response.raise_for_status()
    user = response.json()
    users.append(user)
    check(f"Regular user {number} can use shared tools without installation", "**ready**" in completion(user, "/health"))

valves = api("GET", "/api/v1/functions/id/video_creator/valves", admin["token"])
valves.update({"WIDTH": 960, "HEIGHT": 540, "FPS": 24, "WAIT_SECONDS": 0, "NARRATION": True})
image = Image.new("RGB", (960, 540), "#102033")
draw = ImageDraw.Draw(image)
draw.rounded_rectangle((80, 80, 880, 460), radius=30, fill="#1e4564", outline="#56dfbf", width=4)
draw.text((150, 220), "Video tools in Docker", fill="white", font_size=44)
draw.text((150, 300), "One image. Shared by every user.", fill="#56dfbf", font_size=30)
buffer = io.BytesIO()
image.save(buffer, format="PNG")
record = api("POST", "/api/v1/files/?process=false", users[0]["token"], files={"file": ("docker-source.png", buffer.getvalue(), "image/png")})
attachment = {"id": record["id"], "type": "file", "name": "docker-source.png", "file": record, "context": "full"}
check("Upload original source through the Docker gateway", bool(record["id"]))

fingerprint_code = "import hashlib,json,pathlib; p=pathlib.Path('/run/video-secrets/video-api-key'); print(hashlib.sha256(p.read_bytes()).hexdigest())"
key_before = docker("exec", "-T", "video-worker", "python", "-c", fingerprint_code).strip()
for renderer in ("hyperframes", "remotion"):
    valves["RENDERER"] = renderer
    api("POST", "/api/v1/functions/id/video_creator/valves/update", admin["token"], json=valves)
    response = completion(users[0], "Create a short narrated source slideshow.", [attachment])
    match = re.search(r"Video job: `(job_[a-z0-9]+)`", response)
    if not match:
        raise RuntimeError("Job was not created: " + response[:300])
    job_id = match.group(1)
    print(f"Rendering {renderer} inside Linux: {job_id}", flush=True)
    for _ in range(300):
        response = completion(users[0], "/status " + job_id)
        if "**completed**" in response:
            break
        if "**failed**" in response:
            log = docker("exec", "-T", "video-worker", "tail", "-60", "/data/" + job_id + "/render.log")
            raise RuntimeError(renderer + " failed:\n" + log)
        time.sleep(2)
    else:
        raise TimeoutError(job_id)
    check(f"{renderer} Linux render with preloaded Kokoro", "**completed**" in response)
    url = re.search(r"\[Video\]\(([^)]+)\)", response).group(1)
    output = httpx.get(url, timeout=60, trust_env=False)
    check(f"{renderer} signed video downloads through the gateway", output.status_code == 200 and len(output.content) > 1000)
    (STATE / (renderer + "-docker.mp4")).write_bytes(output.content)
    check(f"{renderer} job blocked for another user", "HTTP 404" in completion(users[1], "/status " + job_id))
    log = docker("exec", "-T", "video-worker", "cat", "/data/" + job_id + "/render.log").lower()
    check(f"{renderer} job runs without installing or downloading tools", not any(value in log for value in ("downloading", "pip install", "npm install")))
    docker("cp", "video-worker:/data/" + job_id + "/thumbnail.jpg", str(STATE / (renderer + "-docker.jpg")))
    report[renderer] = {"job_id": job_id, "bytes": len(output.content)}

check("Worker management API is not exposed by the gateway", client.get("/video/health").status_code == 404)
docker("restart", "video-worker")
for _ in range(60):
    try:
        if "**ready**" in completion(admin, "/health"):
            break
    except Exception:
        pass
    time.sleep(2)
else:
    raise RuntimeError("Worker did not recover after restart")
key_after = docker("exec", "-T", "video-worker", "python", "-c", fingerprint_code).strip()
check("Worker API key preserved after restart", key_before == key_after)
check("Completed jobs survive worker restart", "**completed**" in completion(users[0], "/status " + report["hyperframes"]["job_id"]))
valves.update({"RENDERER": "hyperframes", "WIDTH": 1920, "HEIGHT": 1080, "FPS": 30, "WAIT_SECONDS": 15})
api("POST", "/api/v1/functions/id/video_creator/valves/update", admin["token"], json=valves)
report["openwebui_version"] = api("GET", "/api/version")["version"]
(STATE / "report.json").write_text(json.dumps(report, indent=2))
print("Docker integration passed. Results: .docker-test/report.json", flush=True)
