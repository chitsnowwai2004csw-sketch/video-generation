"""Image-build-only provisioning. Never called when a user submits a job."""
import hashlib
import json
import os
import shutil
import subprocess
import sys
import urllib.request
from pathlib import Path

root = Path("/opt/video-tools")
models = root / "models"
models.mkdir(parents=True, exist_ok=True)
cache = Path("/var/cache/video-models")
cache.mkdir(parents=True, exist_ok=True)
release = "https://github.com/thewh1teagle/kokoro-onnx/releases/download/model-files-v1.0/"
checksums = {
    "kokoro-v1.0.onnx": "7d5df8ecf7d4b1878015a32686053fd0eebe2bc377234608764cc0ef3636a6c5",
    "voices-v1.0.bin": "bca610b8308e8d99f32e6fe4197e7ec01679264efed0cac9140fe9c29f1fbf7d",
}
for filename, expected in checksums.items():
    path = models / filename
    cached = cache / filename
    def digest(file):
        with file.open("rb") as input:
            return hashlib.file_digest(input, "sha256").hexdigest()
    if not cached.is_file() or digest(cached) != expected:
        print("Preloading " + filename, flush=True)
        temporary = cache / (filename + ".part")
        with urllib.request.urlopen(release + filename, timeout=180) as response, temporary.open("wb") as output:
            while chunk := response.read(1024 * 1024):
                output.write(chunk)
        if digest(temporary) != expected:
            raise RuntimeError("Checksum mismatch: " + filename)
        temporary.replace(cached)
    if digest(cached) != expected:
        raise RuntimeError("Checksum mismatch: " + filename)
    shutil.copyfile(cached, path)
config = {
    "node": "/usr/local/bin/node", "tools_root": str(root),
    "hyperframes": str(root / "node_modules/hyperframes/bin/hyperframes.mjs"),
    "kokoro_python": sys.executable, "kokoro_model": str(models / "kokoro-v1.0.onnx"),
    "kokoro_voices": str(models / "voices-v1.0.bin"),
    "browser_executable": "/usr/bin/chromium", "hyperframes_browser": "/usr/bin",
    "ffmpeg": "/usr/bin/ffmpeg", "ffprobe": "/usr/bin/ffprobe",
}
(root / "tools.json").write_text(json.dumps(config), encoding="utf-8")
(root / "remotion-browser.json").write_text(json.dumps({"path": "/usr/bin/chromium", "type": "user-defined-path"}))
# Verify the voice runtime against local models before publishing the image.
import soundfile as sf
from kokoro_onnx import Kokoro
voice = Kokoro(config["kokoro_model"], config["kokoro_voices"])
samples, rate = voice.create("The shared video server is ready.", voice="af_heart", speed=1.0, lang="en-us")
sf.write("/tmp/kokoro-build-check.wav", samples, rate)
Path("/tmp/kokoro-build-check.wav").unlink()
subprocess.run(["node", config["hyperframes"], "--version"], check=True)
subprocess.run(["/usr/bin/chromium", "--version"], check=True)
print("Shared tools and voice models are baked into the image.", flush=True)
