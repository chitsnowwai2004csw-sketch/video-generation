"""One-time authenticated setup; the worker key stays inside the Docker network."""
import argparse
import getpass
import json
import os
import sys
from pathlib import Path

import httpx

parser = argparse.ArgumentParser()
parser.add_argument("--credentials-stdin", action="store_true", help="Read an admin email/password JSON object from stdin")
parser.add_argument("--private", action="store_true", help="Keep the model owner-only instead of granting read access to all users")
args = parser.parse_args()
if args.credentials_stdin:
    credentials = json.load(sys.stdin)
else:
    print("Create your administrator account in Open WebUI first. This command configures the shared Video Creator model.")
    credentials = {"email": input("Open WebUI administrator email: ").strip(), "password": getpass.getpass("Administrator password: ")}

base = os.environ.get("OPENWEBUI_URL", "http://openwebui:8080").rstrip("/")
key = Path(os.environ["VIDEO_API_KEY_FILE"]).read_text().strip()
function_id = "video_creator"
with httpx.Client(base_url=base, timeout=90, trust_env=False) as client:
    response = client.post("/api/v1/auths/signin", json=credentials)
    if response.status_code != 200:
        raise SystemExit("Administrator sign-in failed. Create the first account in the browser and check your credentials.")
    account = response.json()
    if account.get("role") != "admin":
        raise SystemExit("An administrator account is required.")
    headers = {"Authorization": "Bearer " + account["token"]}

    def api(method, path, **kwargs):
        result = client.request(method, path, headers=headers, **kwargs)
        if result.status_code >= 400:
            raise SystemExit(f"Configuration failed: {method} {path}: HTTP {result.status_code}. Check Open WebUI logs.")
        return result.json()

    existing = client.get(f"/api/v1/functions/id/{function_id}", headers=headers)
    form = {"id": function_id, "name": "Video Creator", "content": Path("/app/video_creator_pipe.py").read_text(encoding="utf-8"),
            "meta": {"description": "Shared HyperFrames, Remotion and Kokoro video worker"}}
    endpoint = f"/api/v1/functions/id/{function_id}/update" if existing.status_code == 200 else "/api/v1/functions/create"
    function = api("POST", endpoint, json=form)
    if not function["is_active"]:
        api("POST", f"/api/v1/functions/id/{function_id}/toggle")
    api("POST", f"/api/v1/functions/id/{function_id}/valves/update", json={
        "VIDEO_API_URL": os.environ.get("VIDEO_API_URL", "http://video-worker:8001"),
        "VIDEO_API_KEY": key, "OPENWEBUI_INTERNAL_URL": base,
        "PUBLIC_OUTPUT_URL": os.environ.get("VIDEO_PUBLIC_URL", "http://localhost:3000/video"),
        "WAIT_SECONDS": 15,
    })
    model_form = {"id": function_id, "name": "Video Creator", "base_model_id": None, "params": {},
                  "meta": {"capabilities": {"file_context": False, "vision": True}},
                  "access_grants": [] if args.private else [{"principal_type": "user", "principal_id": "*", "permission": "read"}]}
    current = client.get(f"/api/v1/models/model?id={function_id}", headers=headers)
    api("POST", "/api/v1/models/model/update" if current.status_code == 200 else "/api/v1/models/create", json=model_form)
    result = api("POST", "/api/chat/completions", json={"model": function_id, "messages": [{"role": "user", "content": "/health"}], "stream": False})
    content = result["choices"][0]["message"]["content"]
    if "**ready**" not in content:
        raise SystemExit("The model was configured, but worker readiness failed. Check docker compose logs video-worker.")
print("Video Creator is configured and its shared tools are ready.")
print("Worker connection and keys are saved automatically. Select Video Creator in Open WebUI.")
print("Model access: " + ("administrator only" if args.private else "all authenticated users"))
