"""Export built images with binary-safe I/O, including on Windows PowerShell."""
import gzip
import shutil
import subprocess
from pathlib import Path

root = Path(__file__).resolve().parents[1]
output = root / "video_creator_docker_images.tar.gz"
images = ["video-creator-worker:1.0.0", "video-creator-webui:0.12.4", "nginx:1.28-alpine"]
print("Exporting Docker images. Databases, keys, and user data are not part of the images.", flush=True)
process = subprocess.Popen(["docker", "image", "save", *images], stdout=subprocess.PIPE)
try:
    with gzip.open(output, "wb", compresslevel=3) as archive:
        shutil.copyfileobj(process.stdout, archive, length=1024 * 1024)
    if process.wait() != 0:
        raise RuntimeError("Docker image export failed")
except BaseException:
    process.terminate()
    process.wait()
    raise
print(f"Image archive: {output.name} ({output.stat().st_size / 1024 / 1024:.1f} MiB)", flush=True)
