"""Create persistent secrets once; preserve existing keys on every restart."""
import os
import secrets
from pathlib import Path

secret_dir = Path("/run/video-secrets")
secret_dir.mkdir(parents=True, exist_ok=True)
for filename in ("video-api-key", "webui-secret-key"):
    path = secret_dir / filename
    try:
        with path.open("x", encoding="utf-8") as output:
            output.write(secrets.token_urlsafe(48))
    except FileExistsError:
        if len(path.read_text().strip()) < 24:
            raise RuntimeError("An existing secret is invalid; restore it from a backup.")
    os.chown(path, 10001, 10001)
    os.chmod(path, 0o600)
data = Path("/data")
data.mkdir(parents=True, exist_ok=True)
os.chown(data, 10001, 10001)
print("Persistent keys and worker data directory are ready. Existing keys preserved.")
