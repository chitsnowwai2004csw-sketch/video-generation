#!/bin/sh
set -eu
export WEBUI_SECRET_KEY="$(cat /run/video-secrets/webui-secret-key)"
exec "$@"
