"""Verify add-on mode against the disposable Open WebUI created by test_stack.py."""
import io
import json
import re
import subprocess
import time
from pathlib import Path

import httpx
from PIL import Image

root = Path(__file__).resolve().parents[1]
state = root / ".docker-test"
credentials = json.loads((state / "credentials.json").read_text())
env_file = state / "addon.env"
env_file.write_text("OPENWEBUI_DOCKER_NETWORK=video-creator_default\nOPENWEBUI_UPSTREAM=video-creator-openwebui-1:8080\nWEBUI_PORT=3001\nBIND_ADDRESS=127.0.0.1\nVIDEO_PUBLIC_URL=http://localhost:3001/video\n")
checks = []


def run(*arguments, addon=False, input=None):
    prefix = ["docker", "compose"]
    if addon:
        prefix += ["--env-file", str(env_file), "-f", "compose.existing.yaml"]
    result = subprocess.run(prefix + list(arguments), cwd=root, input=input, text=True,
                            encoding="utf-8", errors="replace", capture_output=True, timeout=300)
    if result.returncode:
        raise RuntimeError((result.stderr + result.stdout)[-2000:])
    return result.stdout


def check(name, condition):
    if not condition:
        raise AssertionError(name)
    checks.append(name)
    print("PASS " + name, flush=True)


original_id = run("ps", "-q", "openwebui").strip()
try:
    print("Starting add-on against the existing disposable Open WebUI container...", flush=True)
    run("up", "-d", "--no-build", addon=True)
    configured = run("--profile", "tools", "run", "--rm", "-T", "configure", "--credentials-stdin", addon=True, input=json.dumps(credentials))
    check("Add-on automatically connects to the existing Open WebUI", "shared tools are ready" in configured)
    check("Existing Open WebUI container is not replaced", original_id == run("ps", "-q", "openwebui").strip())
    with httpx.Client(base_url="http://127.0.0.1:3001", timeout=120, trust_env=False) as client:
        response = client.post("/api/v1/auths/signin", json={"email": "docker-video-user-2@example.com", "password": credentials["password"]})
        response.raise_for_status()
        user = response.json()
        headers = {"Authorization": "Bearer " + user["token"]}
        def chat(text, files=None):
            body = {"model": "video_creator", "messages": [{"role": "user", "content": text}], "stream": False}
            if files:
                body["files"] = files
            reply = client.post("/api/chat/completions", headers=headers, json=body)
            reply.raise_for_status()
            return reply.json()["choices"][0]["message"]["content"]
        check("Existing regular user can use the add-on gateway", "**ready**" in chat("/health"))
        buffer = io.BytesIO()
        Image.new("RGB", (640, 360), "#245c78").save(buffer, format="PNG")
        response = client.post("/api/v1/files/?process=false", headers=headers, files={"file": ("addon-source.png", buffer.getvalue(), "image/png")})
        response.raise_for_status()
        record = response.json()
        answer = chat("Create a short source montage.", [{"id": record["id"], "type": "file", "file": record, "name": "addon-source.png", "context": "full"}])
        match = re.search(r"Video job: `(job_[a-z0-9]+)`", answer)
        if not match:
            raise RuntimeError(answer[:300])
        job_id = match.group(1)
        print("Rendering through add-on: " + job_id, flush=True)
        for _ in range(300):
            answer = chat("/status " + job_id)
            if "**completed**" in answer:
                break
            if "**failed**" in answer:
                raise RuntimeError("Add-on render failed: " + job_id)
            time.sleep(2)
        else:
            raise TimeoutError(job_id)
        check("Add-on worker renders with preloaded shared tools", "**completed**" in answer)
        url = re.search(r"\[Video\]\(([^)]+)\)", answer).group(1)
        download = httpx.get(url, timeout=60, trust_env=False)
        check("Signed add-on downloads use the existing-WebUI gateway", "localhost:3001/video/" in url and download.status_code == 200)
        (state / "addon-docker.mp4").write_bytes(download.content)
        check("Add-on management API is not public", client.get("/video/health").status_code == 404)
    (state / "addon-report.json").write_text(json.dumps({"checks": checks, "job_id": job_id}, indent=2))
finally:
    # Restore only the disposable test stack's Pipe, then stop the add-on without
    # removing its persisted test data/keys. No unrelated deployment is touched.
    restored = run("--profile", "tools", "run", "--rm", "-T", "configure", "--credentials-stdin", input=json.dumps(credentials))
    print("Primary test Pipe restored.", flush=True)
    run("down", addon=True)
print("Existing-Open-WebUI add-on checks passed.", flush=True)
