// Imports resolve from the shared installation, not the user's uploaded project.
import {createRequire} from 'node:module';
import fs from 'node:fs';
import path from 'node:path';
const [mode, toolsRoot, project] = process.argv.slice(2);
const require = createRequire(path.join(toolsRoot, 'package.json'));
const {ensureBrowser, renderMedia, selectComposition} = require('@remotion/renderer');
if (mode === 'ensure-browser') {
  process.chdir(toolsRoot);
  const markerPath = path.join(toolsRoot, 'remotion-browser.json');
  const existing = fs.existsSync(markerPath) ? JSON.parse(fs.readFileSync(markerPath, 'utf8')) : null;
  if (existing?.path && fs.existsSync(existing.path)) {
    console.log('Remotion browser cache reused.');
  } else {
    const browser = await ensureBrowser();
    fs.writeFileSync(markerPath, JSON.stringify(browser));
  }
} else if (mode === 'render') {
  const {bundle} = require('@remotion/bundler');
  const marker = JSON.parse(fs.readFileSync(path.join(toolsRoot, 'remotion-browser.json'), 'utf8'));
  // An explicit executable prevents the renderer from downloading Chrome per job.
  const browserExecutable = marker.path;
  if (!browserExecutable || !fs.existsSync(browserExecutable)) throw Error('Run shared tools setup to preload the Remotion browser.');
  const serveUrl = await bundle({
    entryPoint: path.join(project, 'index.jsx'),
    publicDir: path.join(project, 'assets'),
    webpackOverride: (config) => ({...config, resolve: {...config.resolve,
      modules: [path.join(toolsRoot, 'node_modules'), ...(config.resolve?.modules || [])]}}),
  });
  const composition = await selectComposition({serveUrl, id: 'Video', browserExecutable});
  await renderMedia({serveUrl, composition, browserExecutable, codec: 'h264',
    outputLocation: path.join(project, 'video.mp4'), concurrency: 1});
} else {
  throw Error('Expected ensure-browser or render.');
}
