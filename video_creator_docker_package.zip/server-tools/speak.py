"""Synthesize scene narration using preinstalled Kokoro and existing local models."""
import json
import sys
from pathlib import Path

import soundfile as sf
from kokoro_onnx import Kokoro

config = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8-sig"))
project = Path(sys.argv[2])
plan = json.loads((project / "plan.json").read_text(encoding="utf-8"))
model = Kokoro(config["kokoro_model"], config["kokoro_voices"])
voice = plan["settings"]["narration"].get("voice", "af_heart")
language = plan["settings"]["narration"].get("language", "en")
languages = {"en": "en-us", "en-us": "en-us", "en-gb": "en-gb", "es": "es", "fr": "fr-fr", "hi": "hi", "it": "it", "pt-br": "pt-br", "ja": "ja", "zh": "zh"}
if language not in languages:
    raise ValueError("The configured narration language is not supported by this worker.")
for index, scene in enumerate(plan["scenes"]):
    samples, rate = model.create(scene["narration"], voice=voice, speed=1.0, lang=languages[language])
    filename = f"voice-{index}.wav"
    sf.write(str(project / "assets" / filename), samples, rate)
    scene["audio"] = filename
    scene["duration"] = max(3, len(samples) / rate + 0.5)
(project / "plan.json").write_text(json.dumps(plan, ensure_ascii=False), encoding="utf-8")
